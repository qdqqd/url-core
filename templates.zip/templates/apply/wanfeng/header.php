    <!-- 顶部导航栏 -->
	<div class="header" id="headerbs">
		<div class="top">
			<!-- 网站logo -->
			<div class="logo">
				<a href="./?u=<?php echo $u?>">
					<img src="<?php echo $theme_config['logo']; ?>" alt="logo">
				</a>
			</div>
			<!-- 顶部导航栏列表 -->
			<div class="top-list">
				<nav>
					<ul>
						<li><a href="./?u=<?php echo $u?>">首页</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>