<?php
//禁用错误报告
error_reporting(0);
$t=htmlspecialchars($_GET["t"]);
$q=htmlspecialchars($_POST["q"]);
if (empty($q)) {
}else{
  if ($t=="b"){
    echo'<script>window.location.href="https://google.qdqqd.com/search?q='.$q.'";</script>';

  }else{
    //默认百度

    echo'<script>window.location.href="https://www.baidu.com/s?ie=utf-8&word='.$q.'";</script>';
  }
};
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="Cache-Control" content="no-siteapp">
  <meta name="referrer" content="no-referrer" />
  <meta name="theme-color" content="#ffffff">
  <link rel="icon" href="icon/280.png?v=1.0.1" sizes="280x280" />
  <link rel="apple-touch-icon-precomposed" href="icon/280.png?v=1.0.1" />
  <meta name="msapplication-TileImage" content="icon/280.png?v=1.0.1" />
  <link rel="shortcut icon" href="icon/32.png?v=1.0.1"/>
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-touch-fullscreen" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="full-screen" content="yes"><!--UC强制全屏-->
  <meta name="browsermode" content="application"><!--UC应用模式-->
  <meta name="x5-fullscreen" content="true"><!--QQ强制全屏-->
  <meta name="x5-page-mode" content="app"><!--QQ应用模式-->
  <title>简单搜索  -  柯艺云</title>
  <link href="style.css?t=<?php echo date("ymdhi"); ?>" rel="stylesheet">
  <script src="https://jsd.cdn.zzko.cn/npm/jquery@3.3.1/dist/jquery.min.js"></script>
  <script src="//at.alicdn.com/t/c/font_4264850_wuflijiuvp9.js"></script>
  <script src="sou.js?t=<?php echo date("ymdhi"); ?>"></script>

<script>
!function(p){"use strict";!function(t){var s=window,e=document,i=p,c="".concat("https:"===e.location.protocol?"https://":"http://","sdk.51.la/js-sdk-pro.min.js"),n=e.createElement("script"),r=e.getElementsByTagName("script")[0];n.type="text/javascript",n.setAttribute("charset","UTF-8"),n.async=!0,n.src=c,n.id="LA_COLLECT",i.d=n;var o=function(){s.LA.ids.push(i)};s.LA?s.LA.ids&&o():(s.LA=p,s.LA.ids=[],o()),r.parentNode.insertBefore(n,r)}()}({id:"Jfpcnt0H2uEfXtSf",ck:"Jfpcnt0H2uEfXtSf"});
</script>
<style>
        body {
            background-image: url("img/pc.jpg"); /* 默认加载的图片 */
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
        }
    </style>

<script>
        window.addEventListener('DOMContentLoaded', function() {
            var screenWidth = window.innerWidth;

            if (screenWidth >= 1024) {
                document.body.style.backgroundImage = "url('img/pc.jpg')"; /* 宽度大于等于1024px时加载的图片 */
            } else {
                document.body.style.backgroundImage = "url('img/pe.jpg')"; /* 宽度小于1024px时加载的图片 */
            }
        });
    </script>

</head>

<body>




    <div id="menu"><i></i></div>
    <div class="list closed">
        <ul>
          <!------>
            <li class="title"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-shuqian"></use></svg> 精品书签</li>
            <li><a rel="nofollow" href="https://picx.xpoet.cn/#/config?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" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>PicX图床</a></li>
            <li><a rel="nofollow" href="https://app.vmcardio.com/#/card/cardList" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>vmcar虚拟卡</a></li>
            <li><a rel="nofollow" href="https://www.ppzhilian.com/clipboard" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>PP直连</a></li>
            <li><a rel="nofollow" href="https://www.daohangtx.com/html/update.html" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>QQ技术导航</a></li>
            <li><a rel="nofollow" href="https://yaohuo.me/bbs/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>妖火网</a></li>
            <li><a rel="nofollow" href="https://hefollo.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>惜染图库</a></li>
            <li><a rel="nofollow" href="https://www.dwz.lc/user/tools/api" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>短网址系统</a></li>
            <li><a rel="nofollow" href="https://www.upyun.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>又拍云</a></li>
            <li><a rel="nofollow" href="https://www.ywyj.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>一网一匠</a></li>
            <li><a rel="nofollow" href="https://cp.anyknew.com/retrieve" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>拷贝兔</a></li>
            <li><a rel="nofollow" href="https://api.aa1.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>夏柔API</a></li>
            <li><a rel="nofollow" href="https://c.binjie.fun/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>AIchatOS</a></li>
            <li><a rel="nofollow" href="https://musetransfer.com" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>MUSE文件传</a></li>
            <li><a rel="nofollow" href="https://pan.qq.cool/?path=/%E7%BE%A4%E5%8F%8B%E6%96%87%E4%BB%B6" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>初夏-QQ盘</a></li>
            <li><a rel="nofollow" href="https://yunpan.qdqqd.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>柯艺云-云盘</a></li>

            <!------>
            <li class="title"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-gongju"></use></svg> 工具</li>
            <li><a rel="nofollow" href="https://tools.miku.ac/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Miku工具</a></li>
            <li><a rel="nofollow" href="https://ip.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>IP查询</a></li>
            <li><a rel="nofollow" href="https://translate.google.cn/?hl=zh-CN" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>谷歌翻译</a></li>
            <li><a rel="nofollow" href="http://www.slimego.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>史莱姆</a></li>
            <li><a rel="nofollow" href="https://feedly.com" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Feedly</a></li>         
            <li><a rel="nofollow" href="https://tool.cccyun.cc/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>彩虹工具网</a></li>
            <li><a rel="nofollow" href="http://www.mdeditor.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>MD编辑器</a></li>
            <li><a rel="nofollow" href="http://cubic-bezier.com" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>贝赛尔曲线</a></li>
            <li><a rel="nofollow" href="/base64/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Base64</a></li>
            <li><a rel="nofollow" href="https://javascriptobfuscator.com/Javascript-Obfuscator.aspx" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>JS混淆器</a></li>
            <li><a rel="nofollow" href="https://ping.pe" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Ping.pe</a></li>
            <li><a rel="nofollow" href="https://ping.chinaz.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>站长Ping</a></li>
            <li><a rel="nofollow" href="https://apkdl.in/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>APK下载</a></li>
            <li><a rel="nofollow" href="http://www.txttool.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>TXT工具</a></li>
            <li><a rel="nofollow" href="http://webact.185.hk/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>在线激活win</a></li>
            <li><a rel="nofollow" href="http://www.ab173.com/zhanzhang/gethttp.php" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>批查网页状态</a></li>
            <li><a rel="nofollow" href="https://ultra.pixivel.moe/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>超分酱</a></li>
            <li><a rel="nofollow" href="https://www.sojson.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>解析json</a></li>
            <li><a rel="nofollow" href="https://douyin.wtf/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>tiktok解析</a></li>
            <li><a rel="nofollow" href="https://accounts.qq.com/#/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>QQ安全中心</a></li>
            <li><a rel="nofollow" href="https://video.ciding.cc/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>蜜蜂去水印</a></li>
            <li><a rel="nofollow" href="http://118.195.237.33/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>一起刷步数</a></li>
            <li><a rel="nofollow" href="http://www.kuoluoyun.cn/hash.php" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>可乐hash</a></li>
            <li><a rel="nofollow" href="http://api.yujn.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>遇见のAPI</a></li>
            <li><a rel="nofollow" href="http://api.caonmtx.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>殇白API</a></li>
            <li><a rel="nofollow" href="https://poe.com/ChatGPT" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>POE-GPT</a></li>
            <li><a rel="nofollow" href="https://qyxx.lanzouu.com/b02ielqjg" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>QYBot框架</a></li>
            <li><a rel="nofollow" href="http://qsign.dev/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>公益Qsign</a></li>



            <!------>
            <li class="title"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-shipin"></use></svg> 视频媒体</li>
            <li><a rel="nofollow" href="https://www.youtube.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use>
</svg> Youtube</a></li>
            <li><a rel="nofollow" href="https://v.qq.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>腾讯视频</a></li>
            <li><a rel="nofollow" href="https://www.youku.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>优酷</a></li>
            <li><a rel="nofollow" href="https://www.iqiyi.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>爱奇艺</a></li>
            <li><a rel="nofollow" href="http://www.acfun.cn/index.html" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>ACFUN</a></li>
            <li><a rel="nofollow" href="https://www.bilibili.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>哔哩哔哩</a></li>
            <li><a rel="nofollow" href="https://www.nfmovies.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>奈非影视</a></li>
            <li><a rel="nofollow" href="https://k1080.net/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>K1080</a></li>
            <li><a rel="nofollow" href="https://www.yunbtv.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>云播TV</a></li>
            <li><a rel="nofollow" href="https://dmxq5.com" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>大米星球影视</a></li>

          <!------> 
            <li class="title"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-youxiang"></use></svg> 邮箱</li>
            <li><a rel="nofollow" href="https://mail.google.com/mail/u/0/#inbox" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Gmail</a></li>
            <li><a rel="nofollow" href="https://outlook.live.com/mail/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Hotmail</a></li>
            <li><a rel="nofollow" href="https://mail.163.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>网易邮箱</a></li>
            <li><a rel="nofollow" href="https://mail.sina.com.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>新浪邮箱</a></li>
            <li><a rel="nofollow" href="https://mail.qq.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>QQ邮箱</a></li>
            <li><a rel="nofollow" href="https://qiye.aliyun.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>阿里邮箱</a></li>

          <!------>

            <li class="title"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-sousuo"></use></svg> 搜索引擎</li>
            <li><a rel="nofollow" href="https://www.google.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-google"></use></svg>Google</a></li>
            <li><a rel="nofollow" href="https://duckduckgo.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>DuckGo</a></li>
            <li><a rel="nofollow" href="https://www.bing.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Bing</a></li>
            <li><a rel="nofollow" href="https:/m.baidu.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>百度</a></li>
            <li><a rel="nofollow" href="https://hk.yahoo.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>雅虎</a></li>
            <li><a rel="nofollow" href="https://www.sogou.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>搜狗</a></li>
            <li><a rel="nofollow" href="https://www.naver.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>NAVER</a></li>
            <li><a rel="nofollow" href="https://mijisou.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>秘迹</a></li>
            <li><a rel="nofollow" href="https://www.dogedoge.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>多吉</a></li>
            <li><a rel="nofollow" href="https://seeres.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>seeres</a></li>

            <!------>
            <li class="title"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-kaifaguanli"></use></svg> 开发</li>
            <li><a rel="nofollow" href="http://www.w3school.com.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>W3school</a></li>
            <li><a rel="nofollow" href="https://github.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Github</a></li>
            <li><a rel="nofollow" href="https://codepen.io/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Codepen</a></li>
            <li><a rel="nofollow" href="https://www.52pojie.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>吾爱破解</a></li>
            <li><a rel="nofollow" href="https://segmentfault.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>SF思否</a></li>
            <li><a rel="nofollow" href="https://cdnjs.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>CdnJs</a></li>
            <li><a rel="nofollow" href="https://fontawesome.com/icons?d=gallery&m=free" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Font A.</a></li>
            <li><a rel="nofollow" href="https://msdn.itellyou.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>MSDN下载</a></li>
            <li><a rel="nofollow" href="https://dash.cloudflare.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>C. flare</a></li>
            <li><a rel="nofollow" href="https://www.swiper.com.cn/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Swiper</a></li>
            <li><a rel="nofollow" href="https://www.crxsoso.com/" target="_blank"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg>Crx搜搜™</a></li>
        </ul>
    </div>
    <div class="mywth" style="width: 200px;">
       <div id="he-plugin-simple"></div> <script>WIDGET = {CONFIG:{"modules":"10234","background":5,"tmpColor":"4A4A4A","tmpSize":"14","cityColor":"4A4A4A","citySize":"14","aqiSize":"14","weatherIconSize":"20","alertIconSize":"16","padding":"0px","shadow":"0","language":"auto","borderRadius":5,"fixed":"false","vertical":"middle","horizontal":"left","key":"a7729e45ee6543108adfc157f54b8178"}}</script> <script src="https://widget.heweather.net/simple/static/js/he-simple-common.js?v=1.1"></script>
    </div>    
    <div id="content">
        <div class="con">
            <div class="shlogo" style="background: url(icon/logo.svg) no-repeat center;"></div>
            <div class="sou">
                <form action="" method="post" target="_self">
                   <?php 
                   if ($t=="b"){
                     echo'<div class="lg" style="background: url(icon/g.svg) no-repeat center/cover;" onclick="window.location.href=\'?t=\';"></div>';

                   }else{
                    //上面知道把默认谷歌改成百度，这里不知道改吗大佬们？。。
                     echo'<div class="lg" style="background: url(icon/baidu.svg) no-repeat center/cover;" onclick="window.location.href=\'?t=b\';"></div>';
                   }

                    ?>
                    <!--input class="t" type="text" value="" name="t" hidden-->
                    <input class="wd" type="text" placeholder="请输入搜索内容" name="q" x-webkit-speech lang="zh-CN" autocomplete="off">
                    <button><svg class="icon" style=" width: 21px; height: 21px; opacity: 0.5;" aria-hidden="true"><use xlink:href="#icon-sousuo"></use></svg></button>
                </form>
                <div id="word"></div>
            </div>
        </div>
        <div class="foot" style="height: 40px;">
          © 2016-<?php echo date("Y") ?> by <a href="https://www.qdqqd.com/" style="color: #777;">柯艺云博客</a> . All rights reserved.<br>
<a target="_blank" href="https://v6.51.la/s/DgP3Kw3IjxoHrT7"><script id="LA-DATA-WIDGET" crossorigin="anonymous" charset="UTF-8" src="https://v6-widget.51.la/v6/Jfpcnt0H2uEfXtSf/quote.js?theme=#777,#777,#777,#777,#777,#777,12&f=12&display=0,0,0,0,0,0,0,1"></script></a></div>
    </div>
</body>
</html>