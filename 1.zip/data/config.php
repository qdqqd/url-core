<?php
//数据库配置 更多免费源码请访问一生相随博客 https://www.520xv.com
$db_config = array(
    "type" => "mysql", //类型
	"host" => "h46.hmsql.cn", //地址
	"port" => 3306, //端口
	"name" => "mysql8249123_db", //库名
	"user" => "mysql8249123", //账号
	"password" => "Es6eZ5TqKS" //密码
);
?>